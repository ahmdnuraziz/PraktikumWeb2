@php
    $nama = "Ahmad Nur";
    echo 'Apa kabar ' , $nama;    
@endphp