<?php
    $nama = "Ahmad Nur";
    echo 'Apa kabar ' , $nama;    
?><?php /**PATH C:\xampp\htdocs\PraktikumWeb2\praktikum09\resources\views/kondisi.blade.php ENDPATH**/ ?>