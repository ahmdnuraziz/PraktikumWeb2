<?php
    $nama = "Aziz";
    $nilai = 90;
?>

<?php if($nilai > 60): ?>
    <?php
        $ket  = 'Lulus'
    ?>
    
<?php else: ?>
    <?php
        $ket = 'Gagal'
    ?>
    
<?php endif; ?>

Siswa <?php echo e($nama); ?> keterangan <?php echo e($ket); ?><?php /**PATH C:\xampp\htdocs\PraktikumWeb2\praktikum09\resources\views/nilai.blade.php ENDPATH**/ ?>