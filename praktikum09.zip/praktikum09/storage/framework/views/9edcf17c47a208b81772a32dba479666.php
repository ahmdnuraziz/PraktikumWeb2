<!DOCTYPE html>
<html>

<head>
    <title>Hasil</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h1>Hasil Formulir</h1>

        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th>Nama</th>
                    <th>TTL</th>
                    <th>Jenis Kelamin</th>
                    <th>Hobi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($data['nama']); ?></td>
                    <td><?php echo e($data['ttl']); ?></td>
                    <td><?php echo e($data['jenis_kelamin']); ?></td>
                    <td><?php echo e($data['hobi']); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\PraktikumWeb2\praktikum09\resources\views/hasil.blade.php ENDPATH**/ ?>